<?php 

require_once 'connection.php';

if ( $_SERVER['REQUEST_METHOD'] == 'POST' ){

    $id = $_POST['id'];
    //$name = $_POST['name'];

    $query = "DELETE FROM contacts WHERE id = '$id' ";

        if ( mysqli_query($conn, $query) ){
            $response["value"] = "success";
            $response["message"] = $name." Successfully deleted";
            echo json_encode($response);
        } else {
            $response["value"] = "failure";
            $response["message"] = "Oops! ".$name." Failed to delete, \n 
            Please try again!";
            echo json_encode($response);
        }

    mysqli_close($conn);

} else {
    $response["value"] = "failure";
    $response["message"] = "Please try again!";
    echo json_encode($response);
}

?>