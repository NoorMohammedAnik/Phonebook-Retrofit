<?php 

require_once 'connection.php';

if ( $_SERVER['REQUEST_METHOD'] == 'POST' ){

    $name = $_POST['name'];
    $cell = $_POST['cell'];

    if ( $name == '' || $cell == '' ){
    
     echo 'Please fill in all data!';

    } else {

        $query = "INSERT INTO contacts (name,cell) VALUES ('$name', '$cell')";

        if ( mysqli_query($conn, $query) ){
            $response["value"] = "success";
            $response["message"] = $name." Added success";
            echo json_encode($response);
        } else {
            $response["value"] = "failure";
            $response["message"] = "Oops! ".$name." Failed to add, \n Please try again!";
            echo json_encode($response);
        }
    }

    mysqli_close($conn);

} else {
    $response["value"] = "failure";
    $response["message"] = "Oops! Try again!";
    echo json_encode($response);
}

?>