<?php 

require_once 'connection.php';

$key = $_GET['key'];
if(strlen($key)>0)
{
$query = "SELECT * FROM contacts WHERE name LIKE '%$key%'";	
}
else
{
	
	$query = "SELECT * FROM contacts ORDER BY id DESC";
    
}
    
	$result = mysqli_query($conn, $query);
        $response = array();
        while( $row = mysqli_fetch_assoc($result) ){
            array_push($response, 
            array(
                'id'=>$row['id'], 
                'name'=>$row['name'], 
                'cell'=>$row['cell']) 
            );
        }
		
        echo json_encode($response);   
    


mysqli_close($conn);

?>