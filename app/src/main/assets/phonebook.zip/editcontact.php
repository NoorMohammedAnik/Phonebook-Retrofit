<?php 

require_once 'connection.php';

if ( $_SERVER['REQUEST_METHOD'] == 'POST' ){

    $id = $_POST['id'];
    $name = $_POST['name'];
    $cell = $_POST['cell'];

    if ( $name == '' || $cell == '' ){

        echo 'Please fill all data!';

    } else {

        $query = "UPDATE contacts SET name='$name', cell='$cell' WHERE id = '$id' ";

        if ( mysqli_query($conn, $query) ){
            $response["value"] = "success";
            $response["message"] = $name." Update Successfully!";
            echo json_encode($response);
        } else {
            $response["value"] = "failure";
            $response["message"] = "Oops! ".$name." Failed to Update, \n Please try again!";
            echo json_encode($response);
        }
    }

    mysqli_close($conn);

} else {
    $response["value"] = "failure";
    $response["message"] = "Oops! Try again!";
    echo json_encode($response);
}

?>